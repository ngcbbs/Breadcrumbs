# 아이템 시스템 예제 코드 (Part 2)

## WeaponItem.cs

```csharp
using UnityEngine;

[CreateAssetMenu(fileName = "New Weapon", menuName = "Inventory/Weapon")]
public class WeaponItem : Item
{
    [Header("무기 속성")]
    public WeaponType weaponType;
    public int damage;
    public float attackSpeed;
    public float attackRange;
    
    [Header("추가 효과")]
    public ElementType elementType = ElementType.None;
    public int elementalDamage;
    
    [Header("장착 설정")]
    public EquipmentSlot equipSlot = EquipmentSlot.Weapon;
    public GameObject weaponPrefab; // 캐릭터에 장착될 모델
    public Vector3 equipPositionOffset;
    public Vector3 equipRotationOffset;
    
    // 생성자에서 기본 타입 설정
    private void OnValidate()
    {
        itemType = ItemType.Weapon;
        isStackable = false;
    }
    
    public override bool Equip(Character character)
    {
        if (character == null)
            return false;
            
        // 기존 무기 해제
        EquipmentSystem equipmentSystem = character.GetComponent<EquipmentSystem>();
        if (equipmentSystem != null)
        {
            // 해당 슬롯에 이미 장비가 있으면 해제
            Item equippedItem = equipmentSystem.GetEquippedItem(equipSlot);
            if (equippedItem != null)
            {
                equipmentSystem.UnequipItem(equipSlot);
            }
            
            // 새 무기 장착
            bool success = equipmentSystem.EquipItem(this, equipSlot);
            
            if (success)
            {
                // 무기 모델 생성 및 장착
                Transform equipPoint = character.GetEquipPoint(equipSlot);
                if (equipPoint != null && weaponPrefab != null)
                {
                    GameObject weaponInstance = Instantiate(weaponPrefab, equipPoint);
                    weaponInstance.transform.localPosition = equipPositionOffset;
                    weaponInstance.transform.localRotation = Quaternion.Euler(equipRotationOffset);
                    
                    // 무기 인스턴스 참조 저장
                    equipmentSystem.SetEquipmentInstance(equipSlot, weaponInstance);
                }
                
                // 캐릭터 스탯 업데이트
                CharacterStats stats = character.GetComponent<CharacterStats>();
                if (stats != null)
                {
                    stats.AddWeaponDamage(damage);
                    stats.AddAttackSpeed(attackSpeed);
                }
                
                Debug.Log($"{character.name}이(가) {itemName}을(를) 장착했습니다.");
                return true;
            }
        }
        
        return false;
    }
    
    public override bool Unequip(Character character)
    {
        if (character == null)
            return false;
            
        EquipmentSystem equipmentSystem = character.GetComponent<EquipmentSystem>();
        if (equipmentSystem != null)
        {
            // 장비 해제
            bool success = equipmentSystem.UnequipItem(equipSlot);
            
            if (success)
            {
                // 무기 모델 제거
                equipmentSystem.DestroyEquipmentInstance(equipSlot);
                
                // 캐릭터 스탯 업데이트
                CharacterStats stats = character.GetComponent<CharacterStats>();
                if (stats != null)
                {
                    stats.RemoveWeaponDamage(damage);
                    stats.RemoveAttackSpeed(attackSpeed);
                }
                
                Debug.Log($"{character.name}이(가) {itemName}을(를) 해제했습니다.");
                return true;
            }
        }
        
        return false;
    }
    
    public override string GetTooltipInfo()
    {
        string baseTooltip = base.GetTooltipInfo();
        
        string weaponInfo = $"\n\n<color=#FFD700>공격력:</color> {damage}";
        
        if (attackSpeed > 0)
        {
            weaponInfo += $"\n<color=#FFD700>공격 속도:</color> {attackSpeed}";
        }
        
        if (attackRange > 0)
        {
            weaponInfo += $"\n<color=#FFD700>공격 범위:</color> {attackRange}";
        }
        
        if (elementType != ElementType.None && elementalDamage > 0)
        {
            string elementColor = GetElementColorHex();
            weaponInfo += $"\n<color={elementColor}>{GetElementTypeText()}:</color> +{elementalDamage}";
        }
        
        return baseTooltip + weaponInfo;
    }
    
    private string GetElementColorHex()
    {
        switch (elementType)
        {
            case ElementType.Fire:
                return "#FF0000"; // 빨간색
            case ElementType.Ice:
                return "#00FFFF"; // 하늘색
            case ElementType.Lightning:
                return "#FFFF00"; // 노란색
            case ElementType.Poison:
                return "#00FF00"; // 초록색
            case ElementType.Holy:
                return "#FFFFFF"; // 하얀색
            default:
                return "#FFFFFF";
        }
    }
    
    private string GetElementTypeText()
    {
        switch (elementType)
        {
            case ElementType.Fire:
                return "화염 대미지";
            case ElementType.Ice:
                return "냉기 대미지";
            case ElementType.Lightning:
                return "번개 대미지";
            case ElementType.Poison:
                return "독 대미지";
            case ElementType.Holy:
                return "신성 대미지";
            default:
                return "";
        }
    }
}

// 무기 타입 열거형
public enum WeaponType
{
    Sword,
    Axe,
    Mace,
    Dagger,
    Spear,
    Bow,
    Crossbow,
    Staff,
    Wand
}

// 원소 타입 열거형
public enum ElementType
{
    None,
    Fire,
    Ice,
    Lightning,
    Poison,
    Holy
}
```
