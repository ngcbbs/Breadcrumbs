# 아이템 시스템 예제 코드 (Part 3)

## ConsumableItem.cs

```csharp
using UnityEngine;

[CreateAssetMenu(fileName = "New Consumable", menuName = "Inventory/Consumable")]
public class ConsumableItem : Item
{
    [Header("소비 효과")]
    public ConsumableType consumableType = ConsumableType.Healing;
    public int effectValue;
    public float effectDuration;
    public GameObject useEffect; // 사용 시 발생할 이펙트
    
    [Header("애니메이션")]
    public string useAnimationTrigger = "UsePotion";
    
    // 생성자에서 기본 타입 설정
    private void OnValidate()
    {
        itemType = ItemType.Consumable;
        isStackable = true;
        maxStackSize = 99;
    }
    
    public override bool Use(Character character)
    {
        if (character == null)
            return false;
            
        bool effectApplied = false;
        
        // 캐릭터 스탯에 효과 적용
        CharacterStats stats = character.GetComponent<CharacterStats>();
        if (stats != null)
        {
            switch (consumableType)
            {
                case ConsumableType.Healing:
                    stats.Heal(effectValue);
                    effectApplied = true;
                    break;
                    
                case ConsumableType.ManaRestore:
                    stats.RestoreMana(effectValue);
                    effectApplied = true;
                    break;
                    
                case ConsumableType.StaminaRestore:
                    stats.RestoreStamina(effectValue);
                    effectApplied = true;
                    break;
                    
                case ConsumableType.TemporaryBuff:
                    // 임시 버프 추가
                    BuffSystem buffSystem = character.GetComponent<BuffSystem>();
                    if (buffSystem != null)
                    {
                        Buff newBuff = new Buff
                        {
                            buffName = itemName,
                            icon = icon,
                            duration = effectDuration,
                            modifiers = GetBuffModifiers()
                        };
                        
                        buffSystem.AddBuff(newBuff);
                        effectApplied = true;
                    }
                    break;
                    
                case ConsumableType.StatusCure:
                    // 상태이상 치료
                    StatusEffectSystem statusSystem = character.GetComponent<StatusEffectSystem>();
                    if (statusSystem != null)
                    {
                        statusSystem.CureStatusEffect((StatusEffectType)effectValue);
                        effectApplied = true;
                    }
                    break;
            }
        }
        
        if (effectApplied)
        {
            // 사용 이펙트 생성
            if (useEffect != null)
            {
                Instantiate(useEffect, character.transform.position + Vector3.up, Quaternion.identity);
            }
            
            // 사용 애니메이션
            Animator animator = character.GetComponent<Animator>();
            if (animator != null && !string.IsNullOrEmpty(useAnimationTrigger))
            {
                animator.SetTrigger(useAnimationTrigger);
            }
            
            Debug.Log($"{character.name}이(가) {itemName}을(를) 사용했습니다.");
            return true; // 사용 성공
        }
        
        return false; // 사용 실패
    }
    
    // 버프 수정자 생성
    private StatModifier[] GetBuffModifiers()
    {
        // 아이템의 효과에 따라 다른 스탯 수정자 생성
        StatModifier[] modifiers = new StatModifier[1]; // 간단한 예시로 하나만 생성
        
        switch (consumableType)
        {
            case ConsumableType.TemporaryBuff when effectValue > 0:
                // 스탯 증가 버프
                modifiers[0] = new StatModifier(
                    StatType.Attack,
                    ModifierType.Additive,
                    effectValue,
                    itemName
                );
                break;
                
            default:
                // 기본 버프 (공격력 10% 증가)
                modifiers[0] = new StatModifier(
                    StatType.Attack,
                    ModifierType.PercentAdd,
                    10f,
                    itemName
                );
                break;
        }
        
        return modifiers;
    }
    
    public override string GetTooltipInfo()
    {
        string baseTooltip = base.GetTooltipInfo();
        
        string effectInfo = "\n\n<color=#00FFFF>효과:</color> ";
        
        switch (consumableType)
        {
            case ConsumableType.Healing:
                effectInfo += $"체력을 {effectValue} 회복합니다.";
                break;
                
            case ConsumableType.ManaRestore:
                effectInfo += $"마나를 {effectValue} 회복합니다.";
                break;
                
            case ConsumableType.StaminaRestore:
                effectInfo += $"스태미나를 {effectValue} 회복합니다.";
                break;
                
            case ConsumableType.TemporaryBuff:
                effectInfo += $"공격력이 {effectValue} 증가합니다. (지속시간: {effectDuration}초)";
                break;
                
            case ConsumableType.StatusCure:
                effectInfo += "상태이상을 치료합니다.";
                break;
        }
        
        return baseTooltip + effectInfo;
    }
}

// 소비 아이템 타입 열거형
public enum ConsumableType
{
    Healing,
    ManaRestore,
    StaminaRestore,
    TemporaryBuff,
    StatusCure
}

// 상태이상 타입 열거형 (ConsumableItem 참조용)
public enum StatusEffectType
{
    Poison = 1,
    Burn = 2,
    Freeze = 3,
    Stun = 4,
    Silence = 5,
    Blind = 6,
    All = 99
}
```

## ItemDatabase.cs

```csharp
using System.Collections.Generic;
using UnityEngine;

// 아이템 데이터베이스 (ScriptableObject)
[CreateAssetMenu(fileName = "ItemDatabase", menuName = "Inventory/ItemDatabase")]
public class ItemDatabase : ScriptableObject
{
    [SerializeField] private List<Item> items = new List<Item>();
    
    // 캐싱용 딕셔너리
    private Dictionary<string, Item> itemById;
    
    // 초기화
    private void OnEnable()
    {
        InitializeDictionary();
    }
    
    // 딕셔너리 초기화
    private void InitializeDictionary()
    {
        itemById = new Dictionary<string, Item>();
        
        foreach (var item in items)
        {
            if (item != null && !string.IsNullOrEmpty(item.name))
            {
                // 중복 검사
                if (!itemById.ContainsKey(item.name))
                {
                    itemById.Add(item.name, item);
                }
                else
                {
                    Debug.LogWarning($"ItemDatabase: 중복 아이템 ID 발견: {item.name}");
                }
            }
        }
    }
    
    // ID로 아이템 가져오기
    public Item GetItemById(string id)
    {
        if (itemById == null)
        {
            InitializeDictionary();
        }
        
        if (itemById.TryGetValue(id, out Item item))
        {
            return item;
        }
        
        Debug.LogWarning($"ItemDatabase: 아이템을 찾을 수 없음: {id}");
        return null;
    }
    
    // 타입으로 아이템 가져오기
    public List<Item> GetItemsByType(ItemType type)
    {
        List<Item> result = new List<Item>();
        
        foreach (var item in items)
        {
            if (item != null && item.itemType == type)
            {
                result.Add(item);
            }
        }
        
        return result;
    }
    
    // 희귀도로 아이템 가져오기
    public List<Item> GetItemsByRarity(ItemRarity rarity)
    {
        List<Item> result = new List<Item>();
        
        foreach (var item in items)
        {
            if (item != null && item.rarity == rarity)
            {
                result.Add(item);
            }
        }
        
        return result;
    }
    
    // 모든 아이템 가져오기
    public List<Item> GetAllItems()
    {
        return new List<Item>(items);
    }
    
    // 아이템 추가 (에디터용)
    public void AddItem(Item item)
    {
        if (item != null && !items.Contains(item))
        {
            items.Add(item);
            
            // 딕셔너리 업데이트
            if (itemById != null && !itemById.ContainsKey(item.name))
            {
                itemById.Add(item.name, item);
            }
        }
    }
}
```
