# AI 컨트롤러 예제 코드 (Part 2)

## AIController.cs (계속)

```csharp
    #region 유틸리티 메서드
    
    private void ChangeState(AIState newState)
    {
        // 이전 상태 종료 처리
        switch (currentState)
        {
            case AIState.Patrol:
                break;
                
            case AIState.Chase:
                // 추적 관련 설정 초기화
                break;
                
            case AIState.Attack:
                // 공격 관련 설정 초기화
                break;
        }
        
        // 새 상태 설정
        currentState = newState;
        
        // 새 상태 초기화
        switch (newState)
        {
            case AIState.Idle:
                agent.isStopped = true;
                stateTimer = Random.Range(1f, 3f);
                break;
                
            case AIState.Patrol:
                agent.isStopped = false;
                agent.speed = patrolSpeed;
                if (patrolPoints.Length > 0)
                {
                    SetNextPatrolPoint();
                }
                else
                {
                    // 순찰 지점이 없으면 Idle 상태로
                    ChangeState(AIState.Idle);
                }
                break;
                
            case AIState.Chase:
                agent.isStopped = false;
                agent.speed = chaseSpeed;
                break;
                
            case AIState.Attack:
                agent.isStopped = true;
                stateTimer = 0.5f; // 공격 준비 시간
                break;
                
            case AIState.Investigate:
                agent.isStopped = false;
                agent.speed = patrolSpeed;
                stateTimer = Random.Range(3f, 5f);
                break;
                
            case AIState.Stunned:
                agent.isStopped = true;
                // stateTimer는 외부에서 설정
                break;
        }
    }
    
    private void SetNextPatrolPoint()
    {
        // 순찰 지점이 없으면 리턴
        if (patrolPoints == null || patrolPoints.Length == 0)
            return;
            
        // 다음 순찰 지점 설정
        if (randomPatrol)
        {
            currentPatrolIndex = Random.Range(0, patrolPoints.Length);
        }
        else
        {
            currentPatrolIndex = (currentPatrolIndex + 1) % patrolPoints.Length;
        }
        
        agent.SetDestination(patrolPoints[currentPatrolIndex].position);
    }
    
    private void DetectPlayer()
    {
        // 이전 감지 상태 저장
        bool wasPlayerDetected = (detectedPlayer != null);
        detectedPlayer = null;
        
        // 시야 범위 내 플레이어 탐색
        Collider[] playersInRange = Physics.OverlapSphere(transform.position, sightRange, LayerMask.GetMask("Player"));
        
        foreach (var playerCollider in playersInRange)
        {
            PlayerController player = playerCollider.GetComponent<PlayerController>();
            
            if (player != null)
            {
                // 거리 계산
                float distanceToPlayer = Vector3.Distance(transform.position, playerCollider.transform.position);
                
                // 시야각 내에 있는지 확인
                Vector3 directionToPlayer = (playerCollider.transform.position - transform.position).normalized;
                float angleToPlayer = Vector3.Angle(transform.forward, directionToPlayer);
                
                // 시야각 내에 있거나 가까운 거리에 있는 경우
                if (angleToPlayer < fieldOfViewAngle * 0.5f || distanceToPlayer < hearingRange * 0.3f)
                {
                    // 시야 방해물 확인
                    RaycastHit hit;
                    if (Physics.Raycast(transform.position + Vector3.up * 1.5f, directionToPlayer, out hit, sightRange, sightMask))
                    {
                        // 플레이어가 보이는 경우
                        if (hit.collider.gameObject == playerCollider.gameObject)
                        {
                            detectedPlayer = playerCollider.gameObject;
                            break;
                        }
                    }
                }
                
                // 소리로 감지 (달리기 상태인 경우)
                if (distanceToPlayer < hearingRange && player.IsRunning)
                {
                    // 소리 방해물 확인 (간소화)
                    detectedPlayer = playerCollider.gameObject;
                    break;
                }
            }
        }
        
        // 플레이어 감지 상태 변경 시 상태 전환
        if (detectedPlayer != null && !wasPlayerDetected)
        {
            // 처음 감지된 경우 추적 상태로 전환
            if (currentState != AIState.Stunned)
            {
                ChangeState(AIState.Chase);
            }
        }
        else if (detectedPlayer == null && wasPlayerDetected)
        {
            // 시야에서 사라진 경우, 현재 상태가 추적이나 공격이면 조사 상태로 전환
            if (currentState == AIState.Chase || currentState == AIState.Attack)
            {
                ChangeState(AIState.Investigate);
            }
        }
    }
    
    private bool IsInAttackRange(Vector3 targetPosition)
    {
        return Vector3.Distance(transform.position, targetPosition) <= attackRange;
    }
    
    private void PerformAttack()
    {
        if (combatSystem != null && detectedPlayer != null)
        {
            // 플레이어 방향으로 공격
            Vector3 direction = (detectedPlayer.transform.position - transform.position).normalized;
            combatSystem.TryAttackInDirection(direction);
            
            // 애니메이션 트리거
            if (animator != null)
            {
                animator.SetTrigger("Attack");
            }
        }
    }
    
    private void UpdateAnimator()
    {
        if (animator != null)
        {
            // 이동 속도 파라미터 업데이트
            animator.SetFloat("Speed", agent.velocity.magnitude);
            
            // 상태 파라미터 업데이트
            animator.SetBool("IsChasing", currentState == AIState.Chase);
            animator.SetBool("IsAttacking", currentState == AIState.Attack);
            animator.SetBool("IsStunned", currentState == AIState.Stunned);
        }
    }
```
