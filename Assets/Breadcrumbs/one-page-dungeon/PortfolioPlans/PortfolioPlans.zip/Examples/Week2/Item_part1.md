# 아이템 시스템 예제 코드 (Part 1)

이 문서는 게임의 아이템 시스템 구현을 보여줍니다. 다양한 아이템 타입과 효과를 구현하고, 장비 및 인벤토리 시스템과 연결됩니다.

## Item.cs

```csharp
using UnityEngine;

[CreateAssetMenu(fileName = "New Item", menuName = "Inventory/Item")]
public class Item : ScriptableObject
{
    [Header("기본 정보")]
    public string itemName;
    public string description;
    public Sprite icon;
    public GameObject prefab;
    public ItemRarity rarity = ItemRarity.Common;
    public ItemType itemType = ItemType.Miscellaneous;
    
    [Header("스택 설정")]
    public bool isStackable = false;
    public int maxStackSize = 1;
    
    [Header("판매 정보")]
    public int buyPrice;
    public int sellPrice;
    
    // 아이템 사용 메서드
    public virtual bool Use(Character character)
    {
        // 기본 구현은 아무것도 하지 않음
        Debug.Log($"{itemName} 아이템 사용됨");
        return true; // 사용 성공
    }
    
    // 아이템 장착 메서드 (장비 아이템 전용)
    public virtual bool Equip(Character character)
    {
        // 기본 구현은 실패 반환
        Debug.Log($"{itemName}은(는) 장착할 수 없는 아이템입니다.");
        return false;
    }
    
    // 아이템 장착 해제 메서드 (장비 아이템 전용)
    public virtual bool Unequip(Character character)
    {
        // 기본 구현은 실패 반환
        return false;
    }
    
    // 아이템 획득 시 호출 메서드
    public virtual void OnPickup(Character character)
    {
        // 아이템 획득 시 필요한 처리
    }
    
    // 아이템 드롭 시 호출 메서드
    public virtual void OnDrop(Character character, Vector3 position)
    {
        // 아이템 드롭 시 필요한 처리
    }
    
    // 아이템 비교 (스택 가능 여부 등 확인용)
    public virtual bool IsEqual(Item other)
    {
        if (other == null)
            return false;
            
        // 기본적으로 ScriptableObject ID 비교
        return this == other;
    }
    
    // 툴팁 정보 제공
    public virtual string GetTooltipInfo()
    {
        string rarityColor = GetRarityColorHex();
        
        string tooltipText = $"<color={rarityColor}><b>{itemName}</b></color>\n";
        tooltipText += $"{GetItemTypeText()}\n\n";
        tooltipText += $"{description}\n";
        
        if (buyPrice > 0)
        {
            tooltipText += $"\n가격: {buyPrice} 골드";
        }
        
        return tooltipText;
    }
    
    // 희귀도에 따른 색상 코드
    private string GetRarityColorHex()
    {
        switch (rarity)
        {
            case ItemRarity.Common:
                return "#FFFFFF"; // 하얀색
            case ItemRarity.Uncommon:
                return "#00FF00"; // 초록색
            case ItemRarity.Rare:
                return "#0080FF"; // 파란색
            case ItemRarity.Epic:
                return "#8000FF"; // 보라색
            case ItemRarity.Legendary:
                return "#FF8000"; // 주황색
            default:
                return "#FFFFFF";
        }
    }
    
    // 아이템 유형 텍스트
    private string GetItemTypeText()
    {
        switch (itemType)
        {
            case ItemType.Weapon:
                return "무기";
            case ItemType.Armor:
                return "방어구";
            case ItemType.Accessory:
                return "장신구";
            case ItemType.Consumable:
                return "소비 아이템";
            case ItemType.Material:
                return "재료";
            case ItemType.Quest:
                return "퀘스트 아이템";
            case ItemType.Miscellaneous:
                return "기타";
            default:
                return "알 수 없음";
        }
    }
}

// 아이템 타입 열거형
public enum ItemType
{
    Weapon,
    Armor,
    Accessory,
    Consumable,
    Material,
    Quest,
    Miscellaneous
}

// 아이템 희귀도 열거형
public enum ItemRarity
{
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
}
```
