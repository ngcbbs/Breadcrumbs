# AI 컨트롤러 예제 코드 (Part 3)

## AIController.cs (계속)

```csharp
    // 외부에서 호출할 수 있는 메서드들
    
    // 피해 받을 때 호출되는 메서드
    public void OnTakeDamage(GameObject attacker)
    {
        // 공격자가 플레이어인 경우
        PlayerController player = attacker.GetComponent<PlayerController>();
        if (player != null)
        {
            // 공격자를 타겟으로 설정
            detectedPlayer = attacker;
            lastKnownPlayerPosition = attacker.transform.position;
            
            // 공격 범위 내에 있으면 공격, 아니면 추적
            if (IsInAttackRange(attacker.transform.position))
            {
                ChangeState(AIState.Attack);
            }
            else
            {
                ChangeState(AIState.Chase);
            }
        }
    }
    
    // 스턴 효과 적용
    public void ApplyStun(float duration)
    {
        ChangeState(AIState.Stunned);
        stateTimer = duration;
    }
    
    // 특정 위치 조사
    public void InvestigatePosition(Vector3 position)
    {
        lastKnownPlayerPosition = position;
        ChangeState(AIState.Investigate);
    }
    
    #endregion
    
    // 디버깅용 시각화
    private void OnDrawGizmosSelected()
    {
        // 시야 범위
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, sightRange);
        
        // 공격 범위
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, attackRange);
        
        // 청각 범위
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, hearingRange);
        
        // 시야각
        Gizmos.color = Color.white;
        Vector3 forward = transform.forward * sightRange;
        float halfFOV = fieldOfViewAngle * 0.5f * Mathf.Deg2Rad;
        Vector3 right = new Vector3(Mathf.Sin(halfFOV), 0, Mathf.Cos(halfFOV)) * sightRange;
        Vector3 left = new Vector3(-right.x, 0, right.z);
        
        right = transform.TransformDirection(right);
        left = transform.TransformDirection(left);
        
        Gizmos.DrawRay(transform.position, forward);
        Gizmos.DrawRay(transform.position, right);
        Gizmos.DrawRay(transform.position, left);
    }
}

// AI 상태 열거형
public enum AIState
{
    Idle,
    Patrol,
    Chase,
    Attack,
    Investigate,
    Stunned
}
```

## EnemySpawner.cs (일부)

```csharp
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [System.Serializable]
    public class EnemySpawnInfo
    {
        public GameObject enemyPrefab;
        public int weight = 1;
        [Range(0, 1)] public float spawnChance = 1f;
    }
    
    [Header("스폰 설정")]
    [SerializeField] private EnemySpawnInfo[] enemyTypes;
    [SerializeField] private Transform[] spawnPoints;
    [SerializeField] private bool randomizeSpawnPoints = true;
    [SerializeField] private int maxEnemiesAtOnce = 5;
    [SerializeField] private float minSpawnDelay = 5f;
    [SerializeField] private float maxSpawnDelay = 15f;
    
    [Header("트리거 설정")]
    [SerializeField] private bool spawnOnTrigger = true;
    [SerializeField] private bool spawnOnStart = false;
    [SerializeField] private bool continuousSpawning = false;
    
    // 현재 활성화된 적 목록
    private List<GameObject> activeEnemies = new List<GameObject>();
    private bool isSpawningActive = false;
    private Coroutine spawningCoroutine;
    
    // 랜덤 적 선택 (가중치 기반)
    private EnemySpawnInfo GetRandomEnemy()
    {
        if (enemyTypes == null || enemyTypes.Length == 0)
            return null;
            
        // 가중치 합계 계산
        int totalWeight = 0;
        foreach (var enemy in enemyTypes)
        {
            totalWeight += enemy.weight;
        }
        
        // 랜덤 값 생성
        int randomValue = Random.Range(0, totalWeight);
        
        // 가중치에 따른 적 선택
        int weightSum =
```
