# 전투 시스템 예제 코드 (Part 2)

## CombatSystem.cs (계속)

```csharp
    // 애니메이션 이벤트에서 호출될 실제 공격 실행 함수
    public void ExecuteAttack()
    {
        // 대미지 계산
        int baseDamage = characterStats.GetAttackDamage();
        bool isCritical = RollForCritical();
        int finalDamage = CalculateDamage(baseDamage, isCritical);
        
        // 공격 영역 내 대상 찾기
        List<GameObject> hitTargets = FindTargetsInAttackRange();
        
        // 대상별 대미지 적용
        foreach (var target in hitTargets)
        {
            ApplyDamage(target, finalDamage, isCritical);
        }
    }
    
    // 공격 종료 (애니메이션 이벤트에서 호출)
    public void EndAttack()
    {
        canAttack = true;
        
        // 이벤트 발생
        OnAttackEnded?.Invoke();
    }
    
    // 공격 범위 내 대상 찾기
    private List<GameObject> FindTargetsInAttackRange()
    {
        List<GameObject> targets = new List<GameObject>();
        
        // 공격 범위 내 콜라이더 검색
        Collider[] colliders = Physics.OverlapSphere(attackOrigin.position, attackRange, targetLayers);
        
        foreach (var collider in colliders)
        {
            // 대상 방향 계산
            Vector3 directionToTarget = (collider.transform.position - attackOrigin.position).normalized;
            
            // 시야각 계산
            float angleToTarget = Vector3.Angle(transform.forward, directionToTarget);
            
            // 공격 각도 내에 있는지 확인
            if (angleToTarget <= attackAngle / 2)
            {
                // 장애물 확인
                RaycastHit hit;
                Vector3 targetPosition = collider.bounds.center;
                Vector3 directionToCenter = (targetPosition - attackOrigin.position).normalized;
                float distanceToTarget = Vector3.Distance(attackOrigin.position, targetPosition);
                
                if (!Physics.Raycast(attackOrigin.position, directionToCenter, out hit, distanceToTarget, obstacleLayer))
                {
                    // 대상에게 가시성이 있으면 타겟 목록에 추가
                    targets.Add(collider.gameObject);
                }
            }
        }
        
        return targets;
    }
    
    // 대미지 적용
    private void ApplyDamage(GameObject target, int damage, bool isCritical)
    {
        IDamageable damageable = target.GetComponent<IDamageable>();
        
        if (damageable != null)
        {
            // 대미지 정보 생성
            DamageInfo damageInfo = new DamageInfo(
                damage,
                DamageType.Physical, // 기본값, 무기에 따라 변경 가능
                gameObject,
                isCritical
            );
            
            // 대미지 적용
            damageable.TakeDamage(damageInfo);
            
            // 이펙트 생성
            if (isCritical && criticalHitEffect != null)
            {
                Instantiate(criticalHitEffect, target.transform.position + Vector3.up, Quaternion.identity);
            }
            else if (hitEffect != null)
            {
                Instantiate(hitEffect, target.transform.position + Vector3.up, Quaternion.identity);
            }
            
            // 사운드 재생
            if (audioSource != null)
            {
                audioSource.clip = isCritical ? criticalHitSound : hitSound;
                audioSource.Play();
            }
            
            // 이벤트 발생
            OnHit?.Invoke(target, damage, isCritical);
        }
    }
    
    // 치명타 확률 계산
    private bool RollForCritical()
    {
        float criticalChance = characterStats.GetCriticalChance();
        return UnityEngine.Random.value <= criticalChance;
    }
    
    // 최종 대미지 계산
    private int CalculateDamage(int baseDamage, bool isCritical)
    {
        float criticalMultiplier = characterStats.GetCriticalDamageMultiplier();
        float damageMultiplier = isCritical ? criticalMultiplier : 1f;
        
        return Mathf.RoundToInt(baseDamage * damageMultiplier);
    }
```
