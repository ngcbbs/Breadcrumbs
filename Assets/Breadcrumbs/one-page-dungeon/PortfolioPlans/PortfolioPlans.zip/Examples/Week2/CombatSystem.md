# 전투 시스템 예제 코드

이 파일은 게임의 핵심 전투 시스템 구현을 보여줍니다. 공격, 방어, 대미지 계산, 무기 시스템, 그리고 스탯 관리를 포함합니다.

## CombatSystem.cs

```csharp
using System.Collections.Generic;
using UnityEngine;

public class CombatSystem : MonoBehaviour
{
    [SerializeField] private CharacterStats characterStats;
    [SerializeField] private WeaponController weaponController;
    
    // 공격 설정
    [SerializeField] private float attackCooldown = 0.5f;
    [SerializeField] private float comboWindowTime = 0.3f;
    
    // 내부 상태
    private bool isAttacking = false;
    private float lastAttackTime = 0f;
    private int currentComboCount = 0;
    private float lastComboTime = 0f;
    
    // 데미지 처리 이벤트
    public delegate void DamageHandler(IDamageable target, DamageInfo damageInfo);
    public event DamageHandler OnDamageDealt;
    
    private void Update()
    {
        // 콤보 시간 초과 체크
        if (currentComboCount > 0 && Time.time > lastComboTime + comboWindowTime)
        {
            ResetCombo();
        }
    }
    
    // 공격 시작
    public bool TryAttack()
    {
        // 쿨다운 확인
        if (Time.time < lastAttackTime + attackCooldown)
        {
            return false;
        }
        
        // 스태미나 확인
        if (!characterStats.TryUseStamina(weaponController.CurrentWeapon.StaminaCost))
        {
            return false;
        }
        
        // 공격 처리
        PerformAttack();
        return true;
    }
    
    private void PerformAttack()
    {
        isAttacking = true;
        lastAttackTime = Time.time;
        
        // 콤보 처리
        currentComboCount = (currentComboCount + 1) % weaponController.CurrentWeapon.MaxCombo;
        if (currentComboCount == 0) currentComboCount = 1;
        lastComboTime = Time.time;
        
        // 현재 무기로 공격 수행
        weaponController.Attack(currentComboCount);
        
        // 애니메이션 이벤트에서 OnAttackHit 호출됨
    }
    
    // 애니메이션 이벤트에서 호출될 히트 처리
    public void OnAttackHit()
    {
        List<IDamageable> targets = weaponController.GetHitTargets();
        
        foreach (var target in targets)
        {
            // 대미지 정보 생성
            DamageInfo damageInfo = new DamageInfo
            {
                Amount = CalculateDamage(target),
                Type = weaponController.CurrentWeapon.DamageType,
                Source = gameObject,
                Critical = IsCriticalHit()
            };
            
            // 대미지 적용
            target.TakeDamage(damageInfo);
            
            // 이벤트 발생
            OnDamageDealt?.Invoke(target, damageInfo);
        }
    }
    
    private float CalculateDamage(IDamageable target)
    {
        // 기본 대미지 계산
        float baseDamage = weaponController.CurrentWeapon.BaseDamage;
        float damageMultiplier = 1.0f + characterStats.GetDamageBonus();
        
        // 방어력 계산 (타겟이 캐릭터인 경우)
        float defense = 0f;
        if (target is CharacterStats targetStats)
        {
            defense = targetStats.Defense;
        }
        
        // 최종 대미지 계산
        float finalDamage = (baseDamage * damageMultiplier) * (100 / (100 + defense));
        return finalDamage;
    }
    
    private bool IsCriticalHit()
    {
        // 크리티컬 확률 기반 판정
        float critChance = characterStats.CriticalChance;
        return Random.value <= critChance;
    }
    
    // 콤보 리셋
    private void ResetCombo()
    {
        currentComboCount = 0;
    }
    
    // 공격 완료 (애니메이션 끝에서 호출)
    public void OnAttackComplete()
    {
        isAttacking = false;
    }
}
```

## DamageInfo.cs

```csharp
using UnityEngine;
using MessagePack;

// 대미지 정보 구조체
[MessagePackObject]
public struct DamageInfo
{
    [Key(0)]
    public float Amount;
    
    [Key(1)]
    public DamageType Type;
    
    [Key(2)]
    public GameObject Source;
    
    [Key(3)]
    public bool Critical;
    
    [Key(4)]
    public Vector3 HitPoint;
    
    [Key(5)]
    public Vector3 HitDirection;
}

// 대미지 타입
public enum DamageType
{
    Physical,
    Fire,
    Ice,
    Lightning,
    Poison
}
```

## IDamageable.cs

```csharp
// 대미지 처리 인터페이스
public interface IDamageable
{
    void TakeDamage(DamageInfo damageInfo);
    bool IsAlive { get; }
}
```

## WeaponController.cs

```csharp
using System.Collections.Generic;
using UnityEngine;

public class WeaponController : MonoBehaviour
{
    // 장착된 무기
    [SerializeField] private WeaponItem equippedWeapon;
    [SerializeField] private Transform weaponSocket;
    [SerializeField] private GameObject currentWeaponObject;
    
    // 공격 컴포넌트
    [SerializeField] private AttackHitbox attackHitbox;
    
    // 프로퍼티
    public WeaponItem CurrentWeapon => equippedWeapon;
    
    private void Start()
    {
        // 초기 무기 장착
        if (equippedWeapon != null)
        {
            EquipWeapon(equippedWeapon);
        }
    }
    
    // 무기 장착
    public void EquipWeapon(WeaponItem weapon)
    {
        // 기존 무기 제거
        if (currentWeaponObject != null)
        {
            Destroy(currentWeaponObject);
        }
        
        // 새 무기 장착
        equippedWeapon = weapon;
        
        if (weapon != null && weapon.prefab != null)
        {
            // 무기 오브젝트 생성
            currentWeaponObject = Instantiate(weapon.prefab, weaponSocket);
            currentWeaponObject.transform.localPosition = Vector3.zero;
            currentWeaponObject.transform.localRotation = Quaternion.identity;
            
            // 무기 히트박스 설정
            attackHitbox = currentWeaponObject.GetComponentInChildren<AttackHitbox>();
            if (attackHitbox == null)
            {
                // 히트박스가 없으면 생성
                GameObject hitboxObject = new GameObject("WeaponHitbox");
                hitboxObject.transform.SetParent(currentWeaponObject.transform);
                hitboxObject.transform.localPosition = Vector3.zero;
                
                attackHitbox = hitboxObject.AddComponent<AttackHitbox>();
                
                // 무기 타입에 따른 콜라이더 설정
                CapsuleCollider collider = hitboxObject.AddComponent<CapsuleCollider>();
                collider.isTrigger = true;
                
                // 무기 타입별 히트박스 크기 조정
                switch (weapon.weaponType)
                {
                    case WeaponType.Sword:
                        collider.radius = 0.1f;
                        collider.height = 1.5f;
                        collider.direction = 2; // Z축 방향
                        hitboxObject.transform.localPosition = new Vector3(0, 0, 0.7f);
                        break;
                    case WeaponType.Axe:
                        collider.radius = 0.2f;
                        collider.height = 1.2f;
                        collider.direction = 2;
                        hitboxObject.transform.localPosition = new Vector3(0, 0, 0.6f);
                        break;
                    case WeaponType.Mace:
                        collider.radius = 0.25f;
                        collider.height = 1.0f;
                        collider.direction = 2;
                        hitboxObject.transform.localPosition = new Vector3(0, 0, 0.5f);
                        break;
                    case WeaponType.Dagger:
                        collider.radius = 0.05f;
                        collider.height = 0.8f;
                        collider.direction = 2;
                        hitboxObject.transform.localPosition = new Vector3(0, 0, 0.4f);
                        break;
                    default:
                        collider.radius = 0.1f;
                        collider.height = 1.0f;
                        collider.direction = 2;
                        hitboxObject.transform.localPosition = new Vector3(0, 0, 0.5f);
                        break;
                }
                
                // 초기에는 비활성화
                collider.enabled = false;
            }
        }
    }
    
    // 공격 실행
    public void Attack(int comboIndex)
    {
        // 애니메이션 트리거
        GetComponentInParent<Animator>()?.SetTrigger("Attack" + comboIndex);
        
        // SFX 재생
        AudioSource audioSource = GetComponent<AudioSource>();
        if (audioSource != null && equippedWeapon.attackSounds.Length > 0)
        {
            int soundIndex = Random.Range(0, equippedWeapon.attackSounds.Length);
            audioSource.PlayOneShot(equippedWeapon.attackSounds[soundIndex]);
        }
    }
    
    // 히트박스 활성화 (애니메이션 이벤트에서 호출)
    public void EnableHitbox()
    {
        if (attackHitbox != null)
        {
            attackHitbox.EnableHitbox();
        }
    }
    
    // 히트박스 비활성화 (애니메이션 이벤트에서 호출)
    public void DisableHitbox()
    {
        if (attackHitbox != null)
        {
            attackHitbox.DisableHitbox();
        }
    }
    
    // 타격된 대상 목록 가져오기
    public List<IDamageable> GetHitTargets()
    {
        return attackHitbox != null ? attackHitbox.GetHitTargets() : new List<IDamageable>();
    }
}
```

## AttackHitbox.cs

```csharp
using System.Collections.Generic;
using UnityEngine;

public class AttackHitbox : MonoBehaviour
{
    // 히트박스 설정
    [SerializeField] private Collider hitboxCollider;
    [SerializeField] private LayerMask targetLayers;
    
    // 히트 대상 목록
    private List<IDamageable> hitTargets = new List<IDamageable>();
    
    private void Awake()
    {
        // 콜라이더 참조 가져오기
        if (hitboxCollider == null)
        {
            hitboxCollider = GetComponent<Collider>();
        }
        
        // 트리거 설정 확인
        if (hitboxCollider != null && !hitboxCollider.isTrigger)
        {
            hitboxCollider.isTrigger = true;
        }
        
        // 초기에는 비활성화
        DisableHitbox();
    }
    
    // 히트박스 활성화
    public void EnableHitbox()
    {
        hitTargets.Clear();
        
        if (hitboxCollider != null)
        {
            hitboxCollider.enabled = true;
        }
    }
    
    // 히트박스 비활성화
    public void DisableHitbox()
    {
        if (hitboxCollider != null)
        {
            hitboxCollider.enabled = false;
        }
    }
    
    // 타격된 대상 목록 반환
    public List<IDamageable> GetHitTargets()
    {
        return new List<IDamageable>(hitTargets);
    }
    
    // 트리거 충돌 감지
    private void OnTriggerEnter(Collider other)
    {
        // 타겟 레이어 확인
        if (((1 << other.gameObject.layer) & targetLayers.value) == 0)
        {
            return;
        }
        
        // 대미지 인터페이스 확인
        IDamageable damageable = other.GetComponent<IDamageable>();
        if (damageable != null && damageable.IsAlive && !hitTargets.Contains(damageable))
        {
            // 동일한 공격으로 중복 히트 방지를 위해 리스트에 추가
            hitTargets.Add(damageable);
            
            // 충돌 지점 및 방향 계산 (차후 넉백 등에 사용)
            Vector3 hitPoint = other.ClosestPoint(transform.position);
            Vector3 hitDirection = (other.transform.position - transform.position).normalized;
            
            // VFX 생성
            CreateHitEffect(hitPoint, hitDirection);
        }
    }
    
    // 타격 이펙트 생성
    private void CreateHitEffect(Vector3 position, Vector3 direction)
    {
        // 타격 파티클 및 사운드 효과
        // (구현은 간단함을 위해 생략)
    }
}
```

## CharacterStats.cs

```csharp
using System;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStats : MonoBehaviour, IDamageable
{
    // 기본 스탯
    [Header("Base Stats")]
    [SerializeField] private float baseHealth = 100f;
    [SerializeField] private float baseStamina = 100f;
    [SerializeField] private float baseStrength = 10f;
    [SerializeField] private float baseDexterity = 10f;
    [SerializeField] private float baseIntelligence = 10f;
    [SerializeField] private float baseDefense = 5f;
    
    // 현재 상태
    [Header("Current Status")]
    [SerializeField] private float currentHealth;
    [SerializeField] private float currentStamina;
    
    // 상태 회복 설정
    [Header("Recovery Settings")]
    [SerializeField] private float staminaRecoveryRate = 10f;
    [SerializeField] private float staminaRecoveryDelay = 1f;
    
    // 내부 변수
    private float lastStaminaUseTime;
    private Dictionary<StatType, List<StatModifier>> statModifiers = new Dictionary<StatType, List<StatModifier>>();
    
    // 이벤트
    public event Action<float, float> OnHealthChanged;
    public event Action<float, float> OnStaminaChanged;
    public event Action OnDeath;
    
    // 프로퍼티
    public float MaxHealth => CalculateFinalStatValue(StatType.Health, baseHealth);
    public float MaxStamina => CalculateFinalStatValue(StatType.Stamina, baseStamina);
    public float Strength => CalculateFinalStatValue(StatType.Strength, baseStrength);
    public float Dexterity => CalculateFinalStatValue(StatType.Dexterity, baseDexterity);
    public float Intelligence => CalculateFinalStatValue(StatType.Intelligence, baseIntelligence);
    public float Defense => CalculateFinalStatValue(StatType.Defense, baseDefense);
    
    public float CurrentHealth => currentHealth;
    public float CurrentStamina => currentStamina;
    
    public bool IsAlive => currentHealth > 0;
    
    private void Awake()
    {
        // 스탯 모디파이어 딕셔너리 초기화
        foreach (StatType statType in Enum.GetValues(typeof(StatType)))
        {
            statModifiers[statType] = new List<StatModifier>();
        }
        
        // 초기 체력 및 스태미나 설정
        currentHealth = MaxHealth;
        currentStamina = MaxStamina;
    }
    
    private void Update()
    {
        // 스태미나 회복
        if (Time.time > lastStaminaUseTime + staminaRecoveryDelay)
        {
            float newStamina = Mathf.Min(currentStamina + staminaRecoveryRate * Time.deltaTime, MaxStamina);
            
            if (newStamina != currentStamina)
            {
                float oldStamina = currentStamina;
                currentStamina = newStamina;
                OnStaminaChanged?.Invoke(oldStamina, currentStamina);
            }
        }
    }
    
    // 대미지 처리 (IDamageable 구현)
    public void TakeDamage(DamageInfo damageInfo)
    {
        if (!IsAlive) return;
        
        // 최종 대미지 계산
        float finalDamage = CalculateDamageTaken(damageInfo);
        
        // 체력 감소
        float oldHealth = currentHealth;
        currentHealth = Mathf.Max(0, currentHealth - finalDamage);
        
        // 이벤트 발생
        OnHealthChanged?.Invoke(oldHealth, currentHealth);
        
        // 사망 확인
        if (currentHealth <= 0)
        {
            Die();
        }
    }
    
    // 스태미나 사용
    public bool TryUseStamina(float amount)
    {
        if (currentStamina < amount)
            return false;
        
        float oldStamina = currentStamina;
        currentStamina -= amount;
        lastStaminaUseTime = Time.time;
        
        OnStaminaChanged?.Invoke(oldStamina, currentStamina);
        return true;
    }
    
    // 체력 회복
    public void Heal(float amount)
    {
        if (!IsAlive) return;
        
        float oldHealth = currentHealth;
        currentHealth = Mathf.Min(currentHealth + amount, MaxHealth);
        
        OnHealthChanged?.Invoke(oldHealth, currentHealth);
    }
    
    // 스탯 변경 적용
    public void AddStatModifier(StatType statType, StatModifier modifier)
    {
        statModifiers[statType].Add(modifier);
    }
    
    public void RemoveStatModifier(StatType statType, StatModifier modifier)
    {
        statModifiers[statType].Remove(modifier);
    }
    
    // 대미지 보너스 계산
    public float GetDamageBonus()
    {
        // 기본 공격력 보너스는 힘을 기반으로 함
        return Strength * 0.01f;
    }
    
    // 크리티컬 확률 계산
    public float CriticalChance => Dexterity * 0.005f;
    
    // 사망 처리
    private void Die()
    {
        // 애니메이션 트리거
        GetComponent<Animator>()?.SetTrigger("Die");
        
        // 이벤트 발생
        OnDeath?.Invoke();
        
        // 추가 사망 처리 로직 (컴포넌트 비활성화 등)
    }
    
    // 대미지 계산
    private float CalculateDamageTaken(DamageInfo damageInfo)
    {
        float damage = damageInfo.Amount;
        
        // 크리티컬 히트 적용
        if (damageInfo.Critical)
        {
            damage *= 1.5f;
        }
        
        // 방어력 적용
        damage = damage * (100 / (100 + Defense));
        
        // 대미지 타입에 따른 저항/약점 적용
        float resistanceMultiplier = GetDamageTypeResistance(damageInfo.Type);
        damage *= resistanceMultiplier;
        
        return damage;
    }
    
    // 대미지 타입별 저항 계산
    private float GetDamageTypeResistance(DamageType damageType)
    {
        // 캐릭터 특성에 따른 저항 또는 약점 계산
        // 간단한 구현을 위해 기본값 1.0 반환
        return 1.0f;
    }
    
    // 최종 스탯 계산
    private float CalculateFinalStatValue(StatType statType, float baseValue)
    {
        float finalValue = baseValue;
        
        // 고정 수치 증가 모디파이어 적용
        foreach (var modifier in statModifiers[statType])
        {
            if (modifier.ModifierType == StatModifierType.Flat)
            {
                finalValue += modifier.Value;
            }
        }
        
        float percentAdditive = 0;
        
        // 가산 퍼센트 모디파이어 적용
        foreach (var modifier in statModifiers[statType])
        {
            if (modifier.ModifierType == StatModifierType.PercentAdditive)
            {
                percentAdditive += modifier.Value;
            }
        }
        
        finalValue *= 1 + percentAdditive;
        
        // 승산 퍼센트 모디파이어 적용
        foreach (var modifier in statModifiers[statType])
        {
            if (modifier.ModifierType == StatModifierType.PercentMultiplicative)
            {
                finalValue *= 1 + modifier.Value;
            }
        }
        
        return finalValue;
    }
}

// 스탯 타입
public enum StatType
{
    Health,
    Stamina,
    Strength,
    Dexterity,
    Intelligence,
    Defense
}

// 스탯 모디파이어 타입
public enum StatModifierType
{
    Flat,               // 고정 수치 증가
    PercentAdditive,    // 가산 퍼센트 (여러 효과가 합산됨)
    PercentMultiplicative // 승산 퍼센트 (각각 독립적으로 곱해짐)
}

// 스탯 모디파이어 클래스
[System.Serializable]
public class StatModifier
{
    public StatType StatType;
    public StatModifierType ModifierType;
    public float Value;
    public object Source; // 효과 출처 (아이템, 스킬 등)
    
    public StatModifier(StatType statType, StatModifierType modifierType, float value, object source)
    {
        StatType = statType;
        ModifierType = modifierType;
        Value = value;
        Source = source;
    }
}
```

## StatusEffect.cs

```csharp
using System;
using UnityEngine;

public class StatusEffect
{
    public string Name { get; private set; }
    public string Description { get; private set; }
    public float Duration { get; private set; }
    public bool IsDebuff { get; private set; }
    public Sprite Icon { get; private set; }
    
    private float startTime;
    private CharacterStats targetStats;
    private StatusEffectType effectType;
    private Action<CharacterStats> onApply;
    private Action<CharacterStats> onRemove;
    private