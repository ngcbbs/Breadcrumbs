# AI 컨트롤러 예제 코드 (Part 1)

이 문서는 기본 AI 컨트롤러 시스템의 구현을 보여줍니다. 상태 머신 패턴을 활용하여 몬스터의 다양한 행동 패턴을 관리하고, 시야 및 감지 시스템을 통해 플레이어와 상호작용합니다.

## AIController.cs

```csharp
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

[RequireComponent(typeof(NavMeshAgent))]
public class AIController : MonoBehaviour
{
    // AI 설정
    [Header("AI 설정")]
    [SerializeField] private float sightRange = 10f;
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private float fieldOfViewAngle = 120f;
    [SerializeField] private float hearingRange = 15f;
    [SerializeField] private float patrolWaitTime = 2f;
    [SerializeField] private float chaseSpeed = 5f;
    [SerializeField] private float patrolSpeed = 2f;
    
    // 순찰 지점 설정
    [Header("순찰 설정")]
    [SerializeField] private Transform[] patrolPoints;
    [SerializeField] private bool randomPatrol = true;
    
    // 컴포넌트 참조
    private NavMeshAgent agent;
    private Animator animator;
    private EnemyStats stats;
    private CombatSystem combatSystem;
    
    // 상태 관리
    private AIState currentState;
    private GameObject detectedPlayer;
    private Vector3 lastKnownPlayerPosition;
    private int currentPatrolIndex = 0;
    private float stateTimer = 0f;
    
    // 시각 관련
    [SerializeField] private LayerMask sightMask;
    
    private void Awake()
    {
        agent = GetComponent<NavMeshAgent>();
        animator = GetComponent<Animator>();
        stats = GetComponent<EnemyStats>();
        combatSystem = GetComponent<CombatSystem>();
        
        // 초기 상태 설정
        ChangeState(AIState.Patrol);
    }
    
    private void Update()
    {
        // 죽은 상태면 모든 AI 처리 중지
        if (stats.IsDead)
        {
            agent.isStopped = true;
            return;
        }
        
        // 플레이어 감지 확인
        DetectPlayer();
        
        // 현재 상태 업데이트
        UpdateCurrentState();
        
        // 애니메이션 파라미터 업데이트
        UpdateAnimator();
    }
    
    private void UpdateCurrentState()
    {
        stateTimer -= Time.deltaTime;
        
        switch (currentState)
        {
            case AIState.Idle:
                UpdateIdleState();
                break;
                
            case AIState.Patrol:
                UpdatePatrolState();
                break;
                
            case AIState.Chase:
                UpdateChaseState();
                break;
                
            case AIState.Attack:
                UpdateAttackState();
                break;
                
            case AIState.Investigate:
                UpdateInvestigateState();
                break;
                
            case AIState.Stunned:
                UpdateStunnedState();
                break;
        }
    }
    
    #region 상태 업데이트 메서드
    
    private void UpdateIdleState()
    {
        // 일정 시간 후 순찰 상태로 전환
        if (stateTimer <= 0)
        {
            ChangeState(AIState.Patrol);
        }
    }
    
    private void UpdatePatrolState()
    {
        // 목적지에 도착한 경우
        if (!agent.pathPending && agent.remainingDistance < agent.stoppingDistance)
        {
            // 일정 시간 대기
            if (stateTimer <= 0)
            {
                // 다음 순찰 지점 설정
                SetNextPatrolPoint();
                stateTimer = patrolWaitTime;
            }
        }
    }
    
    private void UpdateChaseState()
    {
        // 플레이어가 감지 상태인 경우
        if (detectedPlayer != null)
        {
            // 플레이어 위치 추적
            agent.SetDestination(detectedPlayer.transform.position);
            lastKnownPlayerPosition = detectedPlayer.transform.position;
            
            // 공격 범위 내에 있는지 확인
            if (IsInAttackRange(detectedPlayer.transform.position))
            {
                ChangeState(AIState.Attack);
            }
        }
        else
        {
            // 마지막 알려진 위치로 이동
            agent.SetDestination(lastKnownPlayerPosition);
            
            // 목적지에 도착한 경우
            if (!agent.pathPending && agent.remainingDistance < agent.stoppingDistance)
            {
                ChangeState(AIState.Investigate);
            }
        }
    }
    
    private void UpdateAttackState()
    {
        // 플레이어가 감지 상태인 경우
        if (detectedPlayer != null)
        {
            // 플레이어를 바라보도록 회전
            Vector3 direction = (detectedPlayer.transform.position - transform.position).normalized;
            Quaternion lookRotation = Quaternion.LookRotation(new Vector3(direction.x, 0, direction.z));
            transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, Time.deltaTime * 5f);
            
            // 공격 쿨다운 확인
            if (stateTimer <= 0)
            {
                // 공격 범위 내에 있는지 다시 확인
                if (IsInAttackRange(detectedPlayer.transform.position))
                {
                    // 공격 실행
                    PerformAttack();
                    stateTimer = combatSystem.GetAttackCooldown();
                }
                else
                {
                    // 범위 밖이면 추적 상태로 전환
                    ChangeState(AIState.Chase);
                }
            }
        }
        else
        {
            // 플레이어 감지가 끊긴 경우 추적 상태로 전환
            ChangeState(AIState.Chase);
        }
    }
    
    private void UpdateInvestigateState()
    {
        // 일정 시간 조사 후 순찰 상태로 전환
        if (stateTimer <= 0)
        {
            ChangeState(AIState.Patrol);
        }
    }
    
    private void UpdateStunnedState()
    {
        // 스턴 시간 종료 후 이전 상태나 순찰 상태로 전환
        if (stateTimer <= 0)
        {
            ChangeState(detectedPlayer != null ? AIState.Chase : AIState.Patrol);
        }
    }
    
    #endregion
```
