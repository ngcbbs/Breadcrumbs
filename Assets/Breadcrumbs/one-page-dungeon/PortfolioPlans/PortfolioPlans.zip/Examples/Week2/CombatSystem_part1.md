# 전투 시스템 예제 코드 (Part 1)

이 문서는 기본 전투 시스템의 구현을 보여줍니다. 공격 메커니즘, 히트박스 처리, 대미지 계산 및 전투 관련 피드백 시스템을 포함합니다.

## CombatSystem.cs

```csharp
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(CharacterStats))]
public class CombatSystem : MonoBehaviour
{
    [Header("공격 설정")]
    [SerializeField] private Transform attackOrigin;
    [SerializeField] private float attackRange = 2f;
    [SerializeField] private float attackAngle = 60f;
    [SerializeField] private float attackCooldown = 1f;
    
    [Header("콤보 설정")]
    [SerializeField] private bool enableCombos = true;
    [SerializeField] private float comboTimeWindow = 1.2f;
    [SerializeField] private int maxComboCount = 3;
    
    [Header("타격 이펙트")]
    [SerializeField] private GameObject hitEffect;
    [SerializeField] private GameObject criticalHitEffect;
    [SerializeField] private AudioClip hitSound;
    [SerializeField] private AudioClip criticalHitSound;
    
    // 레이어 마스크 및 충돌 설정
    [SerializeField] private LayerMask targetLayers;
    [SerializeField] private LayerMask obstacleLayer;
    
    // 컴포넌트 참조
    private CharacterStats characterStats;
    private Animator animator;
    private AudioSource audioSource;
    
    // 상태 변수
    private bool canAttack = true;
    private float lastAttackTime;
    private int currentCombo = 0;
    private float comboTimer = 0f;
    
    // 이벤트
    public event Action<GameObject, int, bool> OnHit;
    public event Action<int> OnComboUpdated;
    public event Action OnAttackStarted;
    public event Action OnAttackEnded;
    
    private void Awake()
    {
        characterStats = GetComponent<CharacterStats>();
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
        
        if (attackOrigin == null)
        {
            attackOrigin = transform;
        }
    }
    
    private void Update()
    {
        // 콤보 타이머 업데이트
        if (currentCombo > 0)
        {
            comboTimer -= Time.deltaTime;
            
            if (comboTimer <= 0)
            {
                ResetCombo();
            }
        }
    }
    
    // 공격 시도
    public bool TryAttack()
    {
        if (!canAttack || Time.time - lastAttackTime < attackCooldown)
        {
            return false;
        }
        
        // 공격 시작
        StartAttack();
        return true;
    }
    
    // 방향을 향해 공격 시도
    public bool TryAttackInDirection(Vector3 direction)
    {
        if (TryAttack())
        {
            // 공격 방향으로 회전
            if (direction != Vector3.zero)
            {
                transform.forward = new Vector3(direction.x, 0, direction.z).normalized;
            }
            
            return true;
        }
        
        return false;
    }
    
    // 공격 시작
    private void StartAttack()
    {
        canAttack = false;
        lastAttackTime = Time.time;
        
        // 콤보 업데이트
        if (enableCombos)
        {
            UpdateCombo();
        }
        
        // 애니메이션 실행
        if (animator != null)
        {
            animator.SetTrigger("Attack");
            
            if (enableCombos)
            {
                animator.SetInteger("ComboCount", currentCombo);
            }
        }
        
        // 이벤트 발생
        OnAttackStarted?.Invoke();
        
        // 실제 공격은 애니메이션 이벤트로 실행
        // 테스트를 위해 직접 호출 옵션도 제공
        // ExecuteAttack();
    }
```
